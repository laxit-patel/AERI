<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    const Alias = "PYMT";
    const PK = "payment_id";
}
