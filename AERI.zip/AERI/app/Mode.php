<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mode extends Model
{
    const Alias = "MODE";
    const PK = "mode_id";
}
