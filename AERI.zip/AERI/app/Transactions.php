<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transactions extends Model
{
    const Alias = "TRNS";
    const PK = "transaction_id";
}
