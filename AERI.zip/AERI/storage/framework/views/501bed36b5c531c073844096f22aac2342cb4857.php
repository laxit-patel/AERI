<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', ['title' => __('Add Material')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row ">
            <div class="col-xl-12  order-xl-1">
                <div class="card bg-secondary  shadow-primary">
                    <div class="card-header  bg-white border-0">
                        <div class="row align-items-center ">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Add Material')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('material.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">

                        <form method="post" action="<?php echo e(route('material.store')); ?>" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                           

                            <div class="row">
                            <div class="col-md-4 form-group<?php echo e($errors->has('material_id') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Material ID')); ?></label>
                                    <input type="text" name="material_id" id="input-name" class="form-control form-control-lg font-weight-bold text-white bg-gradient-warning form-control-alternative<?php echo e($errors->has('material_id') ? ' is-invalid' : ''); ?>" value="<?php echo e($key); ?>" required autofocus disabled>

                                    <?php if($errors->has('material_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('material_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-8 form-group<?php echo e($errors->has('material_name') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Material Name')); ?></label>
                                    <input type="text" name="material_name" id="input-name" class="form-control form-control-lg font-weight-bold text-white bg-gradient-warning <?php echo e($errors->has('material_name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('material_name')); ?>" required autofocus>

                                    <?php if($errors->has('material_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('material_name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            

                            <div class=" form-group<?php echo e($errors->has('material_description') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-details"><?php echo e(__('Material Description')); ?></label>
                                    <textarea name="material_description" id="input-details" class="form-control bg-gradient-warning form-control-lg text-white <?php echo e($errors->has('material_description') ? ' is-invalid' : ''); ?>" placeholder="Material Description" value="<?php echo e(old('material_description')); ?>" required></textarea>

                                    <?php if($errors->has('material_description')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('material_description')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <!-- Remnent of last file operations
                                <div class="row">

                                <div class=" custom-file col-md-6 form-group<?php echo e($errors->has('material_worksheet_format') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label " for="input-password"><?php echo e(__('Upload Material Format')); ?></label>
                                    <input type="file" name="material_worksheet_format" id="input-password" class="  text-white  form-control form-control-lg font-weight-bold  bg-gradient-orange     form-control-alternative<?php echo e($errors->has('material_worksheet_format') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Upload Material Worksheet')); ?>" value="<?php echo e(old('material_worksheet_format')); ?>" required>
                                
                                    <?php if($errors->has('material_worksheet_format')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('material_worksheet_format')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6 form-group<?php echo e($errors->has('material_report_format') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label " for="input-password"><?php echo e(__('Upload Material Report')); ?></label>
                                    <input type="file" name="material_report_format" id="input-password" class="  text-white  form-control form-control-lg font-weight-bold  bg-gradient-orange     form-control-alternative<?php echo e($errors->has('material_report_format') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Upload Material Format')); ?>" value="<?php echo e(old('material_report_format')); ?>" required>
                                
                                    <?php if($errors->has('material_report_format')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('material_report_format')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                </div>
                                -->
                                

                                

                                <div class="text-center">
                                    <button type="submit" class="btn btn-block btn-lg  btn-success mt-4"><?php echo e(__('Add')); ?></button>
                                </div>
                            
                        </form>
                    </div>
                </div>
            </div>

            

        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AERI\resources\views/material/create.blade.php ENDPATH**/ ?>