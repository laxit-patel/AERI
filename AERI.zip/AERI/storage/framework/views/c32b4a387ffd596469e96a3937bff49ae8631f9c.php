<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', ['title' => __('Add Inward')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   


    <?php $__env->startPush('css'); ?>
    <link type="text/css" href="<?php echo e(asset('argon')); ?>/vendor/Chosen/chosen.css" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <div class="container-fluid mt--7 shadow-lg">
        <div class="row ">
            <div class="col-xl-12  order-xl-1">
                <div class="card bg-secondary  shadow-primary">
                    <div class="card-header  bg-white border-0">
                        <div class="row align-items-center ">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Add Inward')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('inward.index')); ?>" class="btn btn-sm bg-gradient-indigo text-white"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('inward.store')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            

                            <div class="row">

                                <div class=" col-md-3 form-group<?php echo e($errors->has('inward_id') ? ' has-danger' : ''); ?>">
                                    
                                    <input type="text" name="inward_id" id="input-id" class="form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('inward_id') ? ' is-invalid' : ''); ?>"  value="<?php echo e($key); ?>" required disabled>

                                    <?php if($errors->has('inward_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class=" col-md-3 form-group<?php echo e($errors->has('inward_reference') ? ' has-danger' : ''); ?>">
                                    
                                    <input type="text" name="inward_reference" id="inward_reference_focus" class="form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('inward_reference') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e($reference); ?>" value="<?php echo e(old('inward_reference')); ?>" required autofocus>

                                    <?php if($errors->has('inward_reference')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_reference')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                   
                                   <div class="col-md-6">
                                   <div class="input-daterange datepicker row align-items-center">
                                <div class="col">
                                    <div class="form-group ">
                                        <div class="input-group input-group-alternative ">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-danger text-white"><i class="ni ni-calendar-grid-58"></i></span>
                                            </div>
                                            <input name="inward_date" class="form-control form-control-lg text-white bg-gradient-danger" placeholder="Inward Date" type="text" >
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-danger text-white"><i class="ni ni-calendar-grid-58"></i></span>
                                            </div>
                                            <input name="inward_report_date" class="form-control form-control-lg text-white bg-gradient-danger" placeholder="Invard Due Date" type="text" >
                                        </div>
                                    </div>
                                </div>
                                </div>
                                </div>

                            </div>

                            <div class="row">

                            <div class=" col-md-12 form-group input-group<?php echo e($errors->has('inward_client') ? ' has-danger' : ''); ?>">
                                    
                                    <select name="inward_client" id="inward_client"  class=" rounded custom-select custom-select-lg form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('inward_client') ? ' is-invalid' : ''); ?>" required >
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-danger display-4" value="<?php echo e($client['client_id']); ?>"><?php echo e($client['client_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('inward_client')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_client')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                            </div>


                            <div class="row">

                            
                            

                            <div class="col-md-4 form-group input-group<?php echo e($errors->has('inward_test') ? ' has-danger' : ''); ?>">
                    
                                <select class="inward-test form-control form-control-lg custom-select custom-select-lg font-weight-bold text-white bg-gradient-danger <?php echo e($errors->has('inward_test') ? ' is-invalid' : ''); ?>" name="inward_test" id="inward_test_datalist">
                                    <option selected disabled>-- Select Test -- </option>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="display-4 bg-danger"  value="<?php echo e($test['test_id']); ?>"><?php echo e($test['test_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>



                                    <?php if($errors->has('inward_test')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_test')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-4 form-group input-group <?php echo e($errors->has('inward_material') ? ' has-danger' : ''); ?>">
                                    
                                    <select name="inward_material" id="inward_material_dropdown" class="custom-select custom-select-lg form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('inward_material') ? ' is-invalid' : ''); ?>" required >
                                        <option selected disabled>No Test Selected</option>
                                        
                                        
                                    </select>


                                    <?php if($errors->has('inward_material')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_material')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                   
                                </div> 

                                <div class=" col-md-2 form-group<?php echo e($errors->has('test_price') ? ' has-danger' : ''); ?>">
                                    
                                    <input type="text" name="test_price" id="test_price" class="form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('test_price') ? ' is-invalid' : ''); ?>" placeholder="Price"  required readonly>

                                    <?php if($errors->has('test_price')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_price')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class=" col-md-2 form-group<?php echo e($errors->has('test_qty') ? ' has-danger' : ''); ?>">
                                    
                                    <input type="text" name="test_qty" id="test_qty" class="form-control form-control-lg font-weight-bold text-white bg-gradient-danger form-control-alternative<?php echo e($errors->has('test_qty') ? ' is-invalid' : ''); ?>" placeholder="Quantity" value="<?php echo e(old('test_qty')); ?>" required >

                                    <?php if($errors->has('test_qty')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_qty')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                            </div>

                         


                            <div class=" form-group<?php echo e($errors->has('inward_description') ? ' has-danger' : ''); ?>">
                                    
                                    <textarea name="inward_description" class="form-control form-control-lg text-white bg-gradient-danger" placeholder="Inward Description" ></textarea>

                                    <?php if($errors->has('inward_description')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('inward_description')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-lg btn-block text-white bg-gradient-success  mt-4"><?php echo e(__('Add')); ?></button>
                                </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


    <?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/Chosen/chosen.proto.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/Chosen/chosen.jquery.js"></script>

    
    <script type="text/javascript">
    
    $("#inward_client").chosen({
        inherit_select_classes: true
    });

    </script>                            
                                
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AERI\resources\views/inward/create.blade.php ENDPATH**/ ?>