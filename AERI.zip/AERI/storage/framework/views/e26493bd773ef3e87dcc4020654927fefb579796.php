<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', ['title' => __('Add Client')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row ">
            <div class="col-xl-12  order-xl-1">
                <div class="card bg-secondary  shadow-primary">
                    <div class="card-header  bg-white border-0">
                        <div class="row align-items-center ">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Add Client')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('client.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('client.store')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            
                            
                            

                            <div class="row">
                            

                                </div>

                                <div class="row">

                                <div class=" col-md-3 form-group<?php echo e($errors->has('client_id') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('ID')); ?></label>
                                    <input type="text" name="client_id" id="input-name" class="disabled form-control form-control-lg font-weight-bold text-white bg-gradient-primary form-control-alternative<?php echo e($errors->has('client_id') ? ' is-invalid' : ''); ?>" placeholder="" value="<?php echo e($key); ?>" required  autofocus disabled>

                                    <?php if($errors->has('client_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>


                                <div class="col-md-5 form-group<?php echo e($errors->has('client_name') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                    <input type="text" name="client_name" id="input-name" class="form-control form-control-lg font-weight-bold text-white bg-gradient-primary form-control-alternative<?php echo e($errors->has('client_name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('client_name')); ?>" required autofocus>

                                    <?php if($errors->has('client_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-4 form-group<?php echo e($errors->has('client_phone') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-password"><?php echo e(__('Phone')); ?></label>
                                    <input type="text" name="client_phone" id="input-password" class="form-control form-control-lg font-weight-bold text-white bg-gradient-primary form-control-alternative<?php echo e($errors->has('client_phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(old('client_phone')); ?>" required>
                                    
                                    <?php if($errors->has('client_phone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                </div>

                                <div class="row">
                                <div class=" col-md-6 form-group<?php echo e($errors->has('client_email') ? ' has-danger' : ''); ?> ">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                                    <input type="email" name="client_email" id="input-email" class="form-control form-control-lg font-weight-bold text-white  bg-gradient-primary  form-control-alternative<?php echo e($errors->has('client_email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('client_email')); ?>" required>

                                    <?php if($errors->has('client_email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6 form-group<?php echo e($errors->has('client_gestin') ? ' has-danger' : ''); ?> ">
                                    <label class="form-control-label" for="input-gstin"><?php echo e(__('GSTIN')); ?></label>
                                    <input type="text" name="client_gstin" id="input-gstin" class="form-control form-control-lg font-weight-bold text-white  bg-gradient-primary  form-control-alternative<?php echo e($errors->has('client_gstin') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('G.S.T')); ?>" value="<?php echo e(old('client_gstin')); ?>" required>

                                    <?php if($errors->has('client_gstin')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_gstin')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                </div>
                                

                                <div class="form-group<?php echo e($errors->has('client_address') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-address"><?php echo e(__('Address')); ?></label>
                                    <textarea name="client_address" id="input-address" class="form-control text-white form-control-lg bg-gradient-primary <?php echo e($errors->has('client_address') ? ' is-invalid' : ''); ?>" placeholder="Client Address" value="<?php echo e(old('client_address')); ?>" required></textarea>
                                    
                                    <?php if($errors->has('client_address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('client_address')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                

                                <div class="text-center">
                                    <button type="submit" class="btn btn-lg btn-block btn-success mt-4"><?php echo e(__('Add')); ?></button>
                                </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AERI\resources\views/client/create.blade.php ENDPATH**/ ?>