<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', ['title' => __('Add New Test')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7 ">
        <div class="row ">
            <div class="col-xl-12  order-xl-1">
                <div class="card bg-secondary  shadow-primary">
                    <div class="card-header  bg-white border-0">
                        <div class="row align-items-center ">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Add New Test')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('material.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('test.store')); ?>" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                            <div class="col-md-3 form-group<?php echo e($errors->has('test_id') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-id"><?php echo e(__('Test Id')); ?></label>
                                    <input type="text" name="test_id" id="input-id" class="form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_id') ? ' is-invalid' : ''); ?>"     value="<?php echo e($key); ?>" required disabled>

                                    <?php if($errors->has('test_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class=" col-md-4 form-group<?php echo e($errors->has('test_iscode') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-reference"><?php echo e(__('Test IS CODE')); ?></label>
                                    <input type="text" name="test_iscode" id="input-ireference" class="form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_iscode') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('IS CODE')); ?>" value="<?php echo e(old('test_iscode')); ?>" required autofocus>

                                    <?php if($errors->has('test_iscode')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_iscode')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-5 form-group<?php echo e($errors->has('test_material') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-material"><?php echo e(__('Test Material')); ?></label>
                                    

                                    <select name="test_material" id="input-material" class="custom-select custom-select-lg form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_material') ? ' is-invalid' : ''); ?>" required autofocus>
                                        <option selected disabled>Select Material</option>
                                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="text-dark" value="<?php echo e($material['material_id']); ?>"><?php echo e($material['material_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('test_material')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_material')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3 form-group<?php echo e($errors->has('test_name') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Test Name')); ?></label>
                                    <input type="text" name="test_name" id="input-name" class="form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('test_name')); ?>" required >

                                    <?php if($errors->has('test_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-3 form-group<?php echo e($errors->has('test_duration') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-material"><?php echo e(__('Test Duration (in Days) ')); ?></label>
                                        
                                            <input type="number" max="365" name="test_duration" id="input-material" class=" form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_duration') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Duration')); ?>" value="<?php echo e(old('test_duration')); ?>" required >
                                            
                                        
                                    <?php if($errors->has('test_duration')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_duration ()')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-3 form-group<?php echo e($errors->has('test_rate') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-rate"><?php echo e(__('Test Rate')); ?></label>
                                    <input type="text" name="test_rate" id="input-rate" class="form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_rate') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Rates')); ?>" value="<?php echo e(old('test_parameter')); ?>" required >

                                    <?php if($errors->has('test_rate')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_rate')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group<?php echo e($errors->has('test_rate_mes') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-rate-mes"><?php echo e(__('Test Rate M.E.S')); ?></label>
                                    <input type="text" name="test_rate_mes" id="input-rate-mes" class="form-control form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_rate_mes') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('M.E.S Rates')); ?>" value="<?php echo e(old('test_rate_mes')); ?>" required >

                                    <?php if($errors->has('test_rate_mes')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_rate_mes')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                
                                

                            </div>

                            <div class="row">

                            
                                <div class="col-md-6 form-group<?php echo e($errors->has('test_worksheet') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-worksheet"><?php echo e(__('Worksheet Format')); ?></label>
                                    <input type="file" name="test_worksheet" id="input-worksheet" class="form-control  form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_worksheet') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Worksheet Format')); ?>" value="<?php echo e(old('test_worksheet')); ?>" required >

                                    <?php if($errors->has('test_worksheet')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_worksheet')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6 form-group<?php echo e($errors->has('test_report') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-report"><?php echo e(__('Report Format')); ?></label>
                                    <input type="file" name="test_report" id="input-report" class="form-control  form-control-lg font-weight-bold text-white bg-gradient-info form-control-alternative<?php echo e($errors->has('test_report') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Report Format')); ?>" value="<?php echo e(old('test_report')); ?>" required >

                                    <?php if($errors->has('test_report')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('test_report')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                             </div>

                                


                                <div class="text-center">
                                    <button type="submit" class="btn btn-lg btn-block btn-success mt-4"><?php echo e(__('Add')); ?></button>
                                </div>
                            
                        </form>
                    </div>
                </div>
            </div>

            

        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AERI\resources\views/test/create.blade.php ENDPATH**/ ?>