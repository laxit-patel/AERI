<?php $__env->startPush('css'); ?>
<!-- Fresh Bootrsap Table-->
<link type="text/css" href="<?php echo e(asset('argon')); ?>/vendor/fresh-table/fresh-bootstrap-table.css" rel="stylesheet">
  
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
       

        <div class="container-fluid mt--7 ">

<div class="row">
<div class="col-12">
                <?php if(session('status')): ?>
                    <div class="alert text-white alert-success text-default alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close test-default" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>    
    <div class="col-xl-12 mb-5 mb-xl-0 ">
    <div class="fresh-table full-color-azure shadow-primary bg-gradient-darker">
                    <!--
                    Available colors for the full background: full-color-blue, full-color-azure, full-color-green, full-color-red, full-color-orange
                    Available colors only for the toolbar: toolbar-color-blue, toolbar-color-azure, toolbar-color-green, toolbar-color-red, toolbar-color-orange
                    -->
                    <div class="toolbar ">
                      
                    &nbsp;
                    <div class=" icon-shape bg-gradient-blue text-white rounded-circle shadow">
                        <i class="fas fa-user "></i> 
                            </div> &nbsp;Clients
                        
                    </div>

                    <table id="fresh-table" class="table">
                                <thead class="text-white font-weight-900 bg-gradient-blue">
                                  <th data-field="id">ID</th>
                                  <th data-field="name" data-sortable="true">Name</th>
                                  <th data-field="email" data-sortable="true">Email</th>
                                  <th data-field="phone" data-sortable="true">Phone</th>
                                  <th data-field="address">Address</th>
                                  <th data-field="actions" data-formatter="operateFormatter" data-events="operateEvents">Actions</th>
                                </thead>
                                <tbody>
                                  
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          

                                <tr class="text-white">
                                
                                <td><?php echo e($client->client_id); ?></td>
                                <td><?php echo e($client->client_name); ?></td>
                                <td><?php echo e($client->client_email); ?></td>
                                <td><?php echo e($client->client_phone); ?></td>
                                <td><?php echo e($client->client_address); ?></td>
                                
                                </tr>
                                
                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </tbody>
                              </table>
                    </div>  
    </div>
    
</div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    

   


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>

    <?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/fresh-table/fresh-table.js"></script>  

<!-- Handle Task Assignment -->
<script type="text/javascript">
function handleSelect(elm)
{
window.location = elm.value;
}
</script>
<!-- task assignment ends -->

<script type="text/javascript">


var $table = $('#fresh-table')
var $alertBtn = $('#alertBtn')

window.operateEvents = {
  
  'click .edit': function (e, value, row, index) {
    location.href = '/edit/'+row._data.inward;
  },
  
}

function operateFormatter(value, row, index) {
  return [
    '<div class="table-action edit"  >',
                                '<a class=" icon-shape bg-gradient-blue text-white rounded-circle shadow">',
                                '<i class="fas fa-edit "></i>',
                                '</a>',
                                '</div>',
    
  ].join('')
}

$(function () {
  $table.bootstrapTable({
    classes: 'table table-hover table-striped',
    toolbar: '.toolbar',

    search: true,
    showRefresh: true,
    showToggle: true,
    showFullscreen: true,
     
    
    pagination: true,
    striped: true,
    sortable: true,
    pageSize: 8,
    pageList: [8, 10, 25, 50, 100],
    

    formatShowingRows: function (pageFrom, pageTo, totalRows) {
      return ''
    },
    formatRecordsPerPage: function (pageNumber) {
      return pageNumber + ' rows visible'
    }
  })

  $alertBtn.click(function () {
    alert('You pressed on Alert')
  })
})

function router()
{
  window.location.href = "/client/create";
}

</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AERI\resources\views/client.blade.php ENDPATH**/ ?>